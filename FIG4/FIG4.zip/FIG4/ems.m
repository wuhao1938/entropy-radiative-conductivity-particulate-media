function f=ems(T)

a=0.98;
b=-53;
c=10.2;
f=a+1e-5*b*T+1e-8*c*T.^2;