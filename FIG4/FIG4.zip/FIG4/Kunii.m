function f=Kunii(epsilon,k)
%Kunii
x=k;
n=1.5;
theta=asin(sqrt(1/n));
pesi1=0.5*(((x-1)./x).^2*(sin(theta))^2)./(log(x-(x-1)*cos(theta))-(x-1)./x*(1-cos(theta)))-2/3./x;
n=4*sqrt(3);
theta=asin(sqrt(1/n));
pesi2=0.5*(((x-1)./x).^2*(sin(theta))^2)./(log(x-(x-1)*cos(theta))-(x-1)./x*(1-cos(theta)))-2/3./x;
pesi=pesi2+(pesi1-pesi2)*(epsilon-0.260)/0.216;
gamma=2/3;
beta=0.895;
f=epsilon+beta*(1-epsilon)./(pesi+gamma./x);