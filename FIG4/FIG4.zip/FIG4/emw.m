function f=emw(T)

a=0.8;
b=36.6;
c=-46.8;
f=a+1e-5*b*T+1e-8*c*T.^2;