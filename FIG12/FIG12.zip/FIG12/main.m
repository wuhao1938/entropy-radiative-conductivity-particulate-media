clear;
clc;

root = pwd;

c1 = [0.16 0.40 0.85];
c2 = [0.86 0.38 0.18];
c3 = [0.34 0.67 0.20];
c4 = [0.55 0.30 0.68];
c5 = [0.14 0.63 0.66];
cm = [0.15 0.15 0.15];

figure('Position',[48 65 1024 768],'Color','w');
hold on

cd(fullfile(root,'C1','TN'))
load Z.mat
X = [Z.meanT];
Y = [Z.keff];
N1 = find(X >= 600 & X < 1200);

cd(fullfile(root,'C1','TA'))
load T.mat
load keff.mat
plot(T,keff,'-','Color',c1,'LineWidth',2.0,'HandleVisibility','off')
H1 = plot(X(N1),Y(N1),'o', ...
    'MarkerSize',7.5, ...
    'MarkerFaceColor',c1, ...
    'MarkerEdgeColor',c1, ...
    'LineWidth',2.0);

cd(fullfile(root,'C2','TN'))
load Z.mat
X = [Z.meanT];
Y = [Z.keff];
N2 = find(X >= 600 & X < 1200);

cd(fullfile(root,'C2','TA'))
load T.mat
load keff.mat
plot(T,keff,'-','Color',c2,'LineWidth',2.0,'HandleVisibility','off')
H2 = plot(X(N2),Y(N2),'s', ...
    'MarkerSize',7.3, ...
    'MarkerFaceColor',c2, ...
    'MarkerEdgeColor',c2, ...
    'LineWidth',2.0);

cd(fullfile(root,'C3','TN'))
load Z.mat
X = [Z.meanT];
Y = [Z.keff];
N3 = find(X >= 600 & X < 1200);

cd(fullfile(root,'C3','TA'))
load T.mat
load keff.mat
plot(T,keff,'-','Color',c3,'LineWidth',2.0,'HandleVisibility','off')
H3 = plot(X(N3),Y(N3),'^', ...
    'MarkerSize',7.8, ...
    'MarkerFaceColor',c3, ...
    'MarkerEdgeColor',c3, ...
    'LineWidth',2.0);

cd(fullfile(root,'C4','TN'))
load Z.mat
X = [Z.meanT];
Y = [Z.keff];
N4 = find(X >= 600 & X < 1200);

cd(fullfile(root,'C4','TA'))
load T.mat
load keff.mat
plot(T,keff,'-','Color',c4,'LineWidth',2.0,'HandleVisibility','off')
H4 = plot(X(N4),Y(N4),'d', ...
    'MarkerSize',7.3, ...
    'MarkerFaceColor',c4, ...
    'MarkerEdgeColor',c4, ...
    'LineWidth',2.0);

cd(fullfile(root,'C5','TN'))
load Z.mat
X = [Z.meanT];
Y = [Z.keff];
N5 = find(X >= 600 & X < 1200);

cd(fullfile(root,'C5','TA'))
load T.mat
load keff.mat
plot(T,keff,'-','Color',c5,'LineWidth',2.2,'HandleVisibility','off')
H5 = plot(X(N5),Y(N5),'h', ...
    'MarkerSize',8.2, ...
    'MarkerFaceColor',c5, ...
    'MarkerEdgeColor',c5, ...
    'LineWidth',2.0);

Hm = plot(nan,nan,'-','Color',cm,'LineWidth',2.4);

cd(root)

axis([590 1210 0 22])



ylabel('\it\lambda\rm\bf (W/m/K)')
xlabel('\it T\rm\bf (K)');
legend1=legend([H1 H2 H3 H4 H5 Hm],...
    'Case 1:\it\bfd\rm\bf=60mm',...
    'Case 2:\it\bfd\rm\bf_1=60mm,\it\bfd\rm\bf_2=90mm',...
    'Case 3:\it\bfd\rm\bf_1=45mm,\it\bfd\rm\bf_2=90mm',...
    'Case 4:\it\bfd\rm\bf_1=45mm,\it\bfd\rm\bf_2=60mm,\it\bfd\rm\bf_3=90mm', ...
    'Case 5:\it\bfd\rm\bf~\it\bfU\rm\bf(45mm, 90mm)','Analytical entropy model','Location','northwest');
set(legend1,...
    'Position',[0.176432291666667 0.611375596788194 0.436431884765625 0.24713134765625],...
    'FontSize',18);


set(gca,'XTick',600:100:1200)
set(gca,'YTick',0:5:20)

set(gca,'XMinorTick','on')
set(gca,'YMinorTick','on')
set(gca,'FontSize',18,'FontWeight','bold','FontName','Times New Roman','LineWidth',2)

set(gcf,'color','none');
set(gca,'color','none');



box on
set(gcf,'InvertHardCopy','off')

lgd = legend;
set(lgd,'Box','off','FontSize',18,'FontName','Times New Roman')

exportgraphics(gcf,'FIG.png','Resolution',300)
exportgraphics(gcf,'FIG.svg','ContentType','vector')
