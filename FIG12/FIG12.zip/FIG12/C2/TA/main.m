clear;
clc;
c=pwd;
cd ..
load V.mat
load voro.vol
vcell = voro(:, end);
d = dir('HTR300000.liggghts');
fid = fopen(d.name);
A = textscan(fid, '', 'headerlines', 9);
fclose(fid);
% id type x y z radius vx vy vz
id = cell2mat(A(1));
type = cell2mat(A(2));
x = cell2mat(A(3));
y = cell2mat(A(4));
z = cell2mat(A(5));
radius = cell2mat(A(6));
cd(c);
P = [x y z];
N = find(pdist2(P, mean(P)) < 0.75);
W=x-x;
d=2*radius;
for i=1:max(size(P))
    if mod(i,1000)==0
        i
    end
    U=V(i,:);
    idx=find(U>0);
    h=pdist2(P(i,:),P(idx,:));
    h=h.^2;
    W(i)=U(idx)*h';
end
S=sum(vcell(N));
A=sum(d(N).^2.*W(N));

T=300:1:1600;
epsilon = 0.8;
sigma = 5.670374419e-8;
keff=2*pi*sigma*epsilon/3/S*A*T.^3;
save T T
save keff keff

