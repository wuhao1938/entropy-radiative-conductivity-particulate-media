clear;
clc;

Ts=400:50:1600;
for i=1:numel(Ts)
    [keff,meanT]=getbed(Ts(i));
    Z(i).meanT=meanT;
    Z(i).keff=keff;
    save Z Z
end









