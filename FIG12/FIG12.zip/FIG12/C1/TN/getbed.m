function [keff,meanT]=getbed(Ts)
c=pwd;
cd ..
load V.mat
load voro.vol
vcell = voro(:, end);
d = dir('HTR1000000.liggghts');
fid = fopen(d.name);
A = textscan(fid, '', 'headerlines', 9);
fclose(fid);
% id type x y z radius vx vy vz 
id = cell2mat(A(1));
type = cell2mat(A(2));
x = cell2mat(A(3));
y = cell2mat(A(4));
z = cell2mat(A(5));
radius = cell2mat(A(6));
cd(c);
P = [x y z];
N = find(pdist2(P, mean(P)) < 0.75);
Qv = 200;
%Ts = 1200;
epsilon = 0.8;
sigma = 5.670374419e-8;
Qi = vcell * Qv;
Ap = 4 * pi * radius.^2;
sigma_eps_Ap = sigma * epsilon * Ap;
w1 = ones(size(x));
Vw1 = V * w1;
T = Ts * ones(size(x));
for i = 1:2000
    i
    E = T.^4;
    radiation = sigma_eps_Ap .* (V * E);
    denominator = sigma_eps_Ap .* Vw1;
    T_new = ((Qi + radiation) ./ denominator).^0.25;
    T(N) = T_new(N);
end


R=pdist2(P(N,:),mean(P));
X=R.^2;
Y=T(N)-Ts;

%plot(X,Y,'.b')

U=X(X<0.4);
V=Y(X<0.4);
s=polyfit(U,V,1);

keff=-Qv/6/s(1);

meanT=mean(U)+Ts;